<html>
<head>
	<script type="text/javascript" src="jquery.min.js"></script>
	<script type="text/javascript" src="script.js"></script>
	<style type="text/css">
	.notificacoes {
		width:30px;
		height:30px;
		background-color:#CCC;
		text-align:center;
		line-height:30px;
		color:#000;
		font-size:16px;
	}
	.tem_notif {
		background-color:#FF0000;
		color:#FFF;
	}
	</style>
</head>
<body>

	<div class="notificacoes">0</div>


	<hr/>

	<button class="addNotif">Criar Notificação</button>

</body>
</html>